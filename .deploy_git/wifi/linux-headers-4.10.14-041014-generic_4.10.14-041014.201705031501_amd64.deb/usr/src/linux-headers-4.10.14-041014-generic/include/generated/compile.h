/* This file is auto generated, version 201705031501 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201705031501 SMP Wed May 3 19:03:05 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 6.3.0 20170406 (Ubuntu 6.3.0-12ubuntu2) "
